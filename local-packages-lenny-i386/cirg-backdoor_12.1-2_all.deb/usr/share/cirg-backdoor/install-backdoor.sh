#!/bin/sh

#Move a config file owned by a Debian package out of the way.
divert () {
    targetFile=$1
    if [ ! `dpkg-divert --list $targetFile` ]
    then
        dpkg-divert --rename --add $targetFile
    fi
}

#setup initial VPN connection, this should only ever be done once
divert /etc/strongswan.conf
cp /usr/share/cirg-backdoor/strongswan.conf /etc/strongswan.conf
chmod 644 /etc/strongswan.conf

divert /etc/ipsec.conf
cp /usr/share/cirg-backdoor/ipsec.conf /etc/ipsec.conf
chmod 644 /etc/ipsec.conf

divert /etc/ipsec.secrets
cp /usr/share/cirg-backdoor/ipsec.secrets /etc/ipsec.secrets
chmod 600 /etc/ipsec.secrets

/etc/init.d/ipsec restart >/dev/null 2>&1 &

#create cirgadmin user
addgroup --gid 5000 cirgadmin
adduser --uid 5000 --ingroup cirgadmin --disabled-password --gecos '' cirgadmin

#install public key for cirgadmin
mkdir -p /home/cirgadmin/.ssh
chown cirgadmin:cirgadmin /home/cirgadmin/.ssh
chmod 700 /home/cirgadmin/.ssh

cp /usr/share/cirg-backdoor/authorized_keys2 \
    /home/cirgadmin/.ssh/authorized_keys2
chown cirgadmin:cirgadmin /home/cirgadmin/.ssh/authorized_keys2

#install some configuration files to help make the VPN more reliable 
cp /usr/share/cirg-backdoor/cirg-backdoor-reload-dhcp \
    /etc/dhcp3/dhclient-exit-hooks.d/cirg-backdoor-reload-dhcp
cp /usr/share/cirg-backdoor/cirg-backdoor-reload-cron \
    /etc/cron.d/cirg-backdoor-reload-cron
