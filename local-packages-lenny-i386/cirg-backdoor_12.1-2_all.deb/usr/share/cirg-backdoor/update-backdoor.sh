#!/bin/sh

#update configuration files except for those involving the initial VPN configuration

if [ -f /home/cirgadmin/.ssh/authorized_keys2 ]; then
    cp /usr/share/cirg-backdoor/authorized_keys2 \
	/home/cirgadmin/.ssh/authorized_keys2
    chown cirgadmin:cirgadmin /home/cirgadmin/.ssh/authorized_keys2
fi

if [ -f /etc/dhcp3/dhclient-exit-hooks.d/cirg-backdoor-reload-dhcp ]; then
    cp /usr/share/cirg-backdoor/cirg-backdoor-reload-dhcp \
	/etc/dhcp3/dhclient-exit-hooks.d/cirg-backdoor-reload-dhcp
fi

if [ -f /etc/cron.d/cirg-backdoor-reload-cron ]; then
    cp /usr/share/cirg-backdoor/cirg-backdoor-reload-cron \
	/etc/cron.d/cirg-backdoor-reload-cron
fi
